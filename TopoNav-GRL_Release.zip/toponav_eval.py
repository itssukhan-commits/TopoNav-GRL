"""Aggregate navigation metrics and visualize TopoNav-Sim results."""
import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean

DATA = Path(__file__).resolve().parent / "data"
METRICS = (
    "success_pct", "collision_pct", "spl", "path_efficiency_pct",
    "time_to_goal_s", "mean_min_clearance_m",
)
INPUT = (
    "group", "seed", "episode_id", "success", "collision", "reference_path_m",
    "executed_path_m", "elapsed_s", "min_clearance_m",
)


def read_csv(path):
    with path.open(newline="", encoding="utf-8-sig") as source:
        return list(csv.DictReader(source))


def summarize(episodes):
    """Compute episode-level metrics for a single policy and condition."""
    successful = [row for row in episodes if row["success"]]
    return {
        "success_pct": 100 * mean(row["success"] for row in episodes),
        "collision_pct": 100 * mean(row["collision"] for row in episodes),
        "spl": sum(
            row["reference_path_m"] / max(row["reference_path_m"], row["executed_path_m"])
            for row in successful
        ) / len(episodes),
        "path_efficiency_pct": 100 * mean(
            row["reference_path_m"] / row["executed_path_m"] for row in successful
        ) if successful else None,
        "time_to_goal_s": mean(row["elapsed_s"] for row in successful) if successful else None,
        "mean_min_clearance_m": mean(row["min_clearance_m"] for row in episodes),
    }


def load_rollouts(path):
    groups = defaultdict(lambda: defaultdict(list))
    seen = set()
    with path.open(newline="", encoding="utf-8-sig") as source:
        reader = csv.DictReader(source)
        missing = set(INPUT) - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"Missing columns: {', '.join(sorted(missing))}")
        for line, row in enumerate(reader, 2):
            try:
                group, seed, episode = (row[key].strip() for key in INPUT[:3])
                key = (group, seed, episode)
                if not all(key) or key in seen:
                    raise ValueError("episode keys must be populated and unique")
                numeric = {field: float(row[field]) for field in INPUT[3:]}
                if any(not math.isfinite(value) or value < 0 for value in numeric.values()):
                    raise ValueError("numeric fields must be finite and nonnegative")
                success, collision = numeric["success"], numeric["collision"]
                if success not in (0, 1) or collision not in (0, 1) or success + collision > 1:
                    raise ValueError("success and collision must be mutually exclusive binary flags")
                if success and min(numeric["reference_path_m"], numeric["executed_path_m"]) <= 0:
                    raise ValueError("successful episodes require positive path lengths")
                seen.add(key)
                groups[group][seed].append(numeric)
            except (ValueError, TypeError, AttributeError) as error:
                raise ValueError(f"{path}, line {line}: {error}") from error
    if not groups:
        raise ValueError("CSV must contain at least one evaluation episode")
    return groups


def aggregate(input_path, output_path):
    groups = load_rollouts(input_path)
    rows = []
    for group, seeds in sorted(groups.items()):
        summaries = [summarize(episodes) for episodes in seeds.values()]
        scores = {}
        for metric in METRICS:
            values = [summary[metric] for summary in summaries]
            scores[metric] = mean(values) if all(value is not None for value in values) else None
        rows.append({
            "group": group,
            "seeds": len(seeds),
            "episodes_min_per_seed": min(map(len, seeds.values())),
            "episodes_max_per_seed": max(map(len, seeds.values())),
            "episode_evaluations": sum(map(len, seeds.values())),
            **scores,
        })
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as destination:
        writer = csv.DictWriter(destination, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_severity(output_path):
    import matplotlib.pyplot as plt

    rows = read_csv(DATA / "severity.csv")
    levels = [row["severity"] for row in rows]
    titles = ("Success rate (%)", "Collision rate (%)", "SPL")
    colors = ("#225987", "#a33d24", "#167565")
    figure, axes = plt.subplots(1, 3, figsize=(9, 3), layout="constrained")
    for index, (axis, metric, title, color) in enumerate(zip(axes, METRICS, titles, colors)):
        values = [float(row[metric]) for row in rows]
        axis.plot(levels, values, marker="o", color=color, linewidth=1.7)
        axis.set_title(f"({chr(97 + index)}) {title}", loc="left")
        axis.set_xlabel("Sensing severity")
        axis.grid(axis="y", alpha=0.3)
        axis.margins(x=0.12, y=0.24)
        axis.spines[["top", "right"]].set_visible(False)
        axis.tick_params(axis="x", labelsize=8)
        for level, value in zip(levels, values):
            label = f"{value:.3f}" if metric == "spl" else f"{value:.1f}"
            axis.annotate(label, (level, value), xytext=(0, 7),
                          textcoords="offset points", ha="center", color=color)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(output_path)
    plt.close(figure)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    rollouts = commands.add_parser("aggregate", help="summarize rollout records across seeds")
    rollouts.add_argument("input", type=Path)
    rollouts.add_argument("output", type=Path)
    plot = commands.add_parser("plot-severity", help="render the manuscript severity results")
    plot.add_argument("output", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "aggregate":
            aggregate(args.input, args.output)
        else:
            plot_severity(args.output)
    except (ValueError, OSError, ImportError) as error:
        parser.exit(1, f"Error: {error}\n")


if __name__ == "__main__":
    main()
